"""Laplace vs importance-sampling evaluation of the multinomial-lognormal likelihood on sparse records."""
import numpy as np, pickle
from qwt import daubechies
from hurst import forms, calib, interp, K
from countfit2 import make_fit
lv, Al, tot = forms(daubechies(2), True, True); U, Rc = calib(Al); fit = make_fit(U, Rc, interp, K)
rs = pickle.load(open("readout3_res.pkl", "rb")); rng = np.random.default_rng(9)
d = []
for (H, Q) in [(0.8, 2**17), (0.9, 2**17), (0.9, 2**20)]:
    for key, Mf in [("Cd", lambda Q: float(Q)), ("Ch", lambda Q: float(Q // K))]:
        sel = [r for r in rs if r["H"] == H and r["Q"] == Q and (r[key] == 0).any() and r[key].sum() > 0][:40]
        for r in sel:
            M = np.full(K, Mf(Q)); a = fit(r[key], M); b = fit(r[key], M, "is", rng)
            d.append((H, Q, key, a[0] - b[0], a[1] - b[1], a[2] - b[2]))
d = np.array([x[3:] for x in d], float)
print("n", len(d), "max|dH|", np.abs(d[:, 0]).max(), "mean|dH|", np.abs(d[:, 0]).mean(), "max|dlo|", np.abs(d[:, 1]).max(), "max|dhi|", np.abs(d[:, 2]).max(),
      "frac|dH|>0.01", np.mean(np.abs(d[:, 0]) > 0.01))
pickle.dump(d, open("ischeck.pkl", "wb"))

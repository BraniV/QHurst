"""Record-only RMSE vs record length: mirror (quantum), periodic (quantum), interior-only (classical trimming).
db2 decimated, window = 6 finest levels, Q = infinity."""
import numpy as np, pickle
from qwt import daubechies, dwt_matrix
from hurst import path_cov, fitH, Hgrid
from recfloor import fgn
import hurst
K = 6; rng = np.random.default_rng(77); h = daubechies(2)
def rows(n, cfg):
    if cfg == "mirror": J = int(np.log2(n)) + 1; M = np.vstack([np.eye(n), np.eye(n)[::-1]])
    else: J = int(np.log2(n)); M = np.eye(n)
    G = dwt_matrix(J, K, h) @ M; out = []
    for j in range(J - K, J):
        Gj = G[2 ** j:2 ** (j + 1)]
        if cfg == "interior":
            Wj = dwt_matrix(J, K, h)[2 ** j:2 ** (j + 1)]
            keep = [i for i, r in enumerate(Wj) if not (abs(r[-1]) > 1e-12 and abs(r[0]) > 1e-12)]
            Gj = Gj[keep]
        out.append(Gj)
    return out
def calib(Gs, n):
    U = []; R = []
    for H in Hgrid:
        S = path_cov(n, H); T = [G @ S for G in Gs]
        e = np.array([np.sum(t * G) for t, G in zip(T, Gs)])
        Gm = np.array([[2 * np.sum((T[a] @ Gs[b].T) ** 2) for b in range(K)] for a in range(K)])
        U.append(np.log2(e)); R.append(Gm / np.outer(e, e))
    return np.array(U), np.array(R)
res = {}
for n in [256, 512, 1024, 2048]:
    setups = {}
    for cfg in ["mirror", "periodic", "interior"]:
        Gs = rows(n, cfg); setups[cfg] = (Gs, *calib(Gs, n))
    Mm = np.vstack([np.eye(n), np.eye(n)[::-1]])
    for H in [0.5, 0.8, 0.9]:
        B = np.cumsum(fgn(n, H, rng, 400), axis=1)
        for cfg, (Gs, U, Rc) in setups.items():
            E = np.stack([np.sum((B @ G.T) ** 2, 1) for G in Gs], 1)
            est = np.array([fitH(np.log2(e), U, Rc, np.zeros(K))[0] for e in E])
            res[(n, H, cfg)] = dict(rmse=np.sqrt(np.mean((est - H) ** 2)), bias=np.mean(est - H))
            if cfg == "mirror":
                nrm = np.sum((B @ Mm.T) ** 2, 1); res[(n, H, cfg)]["pmin"] = np.median((E / nrm[:, None]).min(1))
            print(n, H, cfg, {k: round(v, 6) for k, v in res[(n, H, cfg)].items()}, flush=True)
pickle.dump(res, open("lengths_res.pkl", "wb"))

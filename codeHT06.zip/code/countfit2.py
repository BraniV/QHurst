"""Multinomial-lognormal count fit. Integrating the flat common log-intercept exactly gives, for C_+ > 0,
L(H) = int Mult(C | C_+, pi(c)) N(c; 0, A_H) dc,  pi_j(c) propto M_j exp(b_j(H) + (Zc)_j),
with Z an orthonormal basis of the contrasts (K x (K-1)) and A_H = Z^T S_H Z.
For C_+ = 0 the intercept integral diverges and the record yields no estimate."""
import numpy as np
from scipy.special import gammaln, logsumexp
LN2 = np.log(2)
def basis(K):
    Q, _ = np.linalg.qr(np.c_[np.ones(K), np.eye(K)[:, :K - 1]]); return Q[:, 1:]
def _setup(H, U, Rc, interp, Z):
    u, S = interp(H, U, Rc); A = Z.T @ S @ Z; Ai = np.linalg.inv(A); return u * LN2, Ai, np.linalg.slogdet(A)[1]
def loglik_laplace(C, M, b, Ai, ldA, Z):
    Cp = C.sum(); k = Z.shape[1]; c = np.zeros(k); lm = np.log(M) + b
    for _ in range(60):
        eta = lm + Z @ c; pi = np.exp(eta - logsumexp(eta))
        g = Z.T @ (C - Cp * pi) - Ai @ c
        Hm = Z.T @ (Cp * (np.diag(pi) - np.outer(pi, pi))) @ Z + Ai
        st = np.linalg.solve(Hm, g); m = np.abs(st).max()
        if m > 2: st *= 2 / m
        c += st
        if m < 1e-10: break
    eta = lm + Z @ c; lpi = eta - logsumexp(eta); pi = np.exp(lpi)
    Hm = Z.T @ (Cp * (np.diag(pi) - np.outer(pi, pi))) @ Z + Ai
    val = np.sum(C * lpi) - 0.5 * c @ Ai @ c - 0.5 * ldA - 0.5 * np.linalg.slogdet(Hm)[1]
    return val, c, Hm
def loglik_is(C, M, b, Ai, ldA, Z, rng, n=20000, df=5):
    """Importance sampling with a multivariate t proposal at the Laplace mode (check of the Laplace value)."""
    _, c0, Hm = loglik_laplace(C, M, b, Ai, ldA, Z); k = len(c0)
    L = np.linalg.cholesky(np.linalg.inv(Hm) * 1.5)
    z = rng.standard_normal((n, k)); w = rng.chisquare(df, n) / df; x = c0 + (z / np.sqrt(w)[:, None]) @ L.T
    # log t density
    q = np.sum(np.linalg.solve(L, (x - c0).T) ** 2, 0)
    logq = gammaln((df + k) / 2) - gammaln(df / 2) - k / 2 * np.log(df * np.pi) - np.log(np.diag(L)).sum() - (df + k) / 2 * np.log1p(q / df)
    eta = np.log(M) + b + x @ Z.T; lpi = eta - logsumexp(eta, axis=1, keepdims=True)
    logp = lpi @ C - 0.5 * np.einsum('ij,jk,ik->i', x, Ai, x) - 0.5 * ldA - k / 2 * np.log(2 * np.pi)
    lw = logp - logq; return logsumexp(lw) - np.log(n) + k / 2 * np.log(2 * np.pi)
def make_fit(U, Rc, interp, K, grid=np.linspace(0.02, 0.98, 49)):
    Z = basis(K); pre = [_setup(H, U, Rc, interp, Z) for H in grid]; fine = np.linspace(grid[0], grid[-1], 961)
    def summarize(ll):
        i = ll.argmax()
        if 0 < i < len(grid) - 1:
            a_, b_, c_ = ll[i - 1], ll[i], ll[i + 1]; den = a_ - 2 * b_ + c_
            Hh = grid[i] + (0.5 * (a_ - c_) / den * (grid[1] - grid[0]) if den < 0 else 0)
        else: Hh = grid[i]
        lf = np.interp(fine, grid, ll); ok = fine[lf >= lf.max() - 1.92]; return Hh, ok.min(), ok.max()
    def fit(C, M, method="laplace", rng=None):
        if C.sum() == 0: return np.nan, np.nan, np.nan, "allzero"
        if method == "laplace": ll = np.array([loglik_laplace(C, M, b, Ai, ld, Z)[0] for b, Ai, ld in pre])
        else: ll = np.array([loglik_is(C, M, b, Ai, ld, Z, rng) for b, Ai, ld in pre])
        return (*summarize(ll), "ok")
    return fit

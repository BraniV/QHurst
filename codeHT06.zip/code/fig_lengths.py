import pickle, numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt, matplotlib.ticker as mt
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#888','axes.grid':True,'grid.color':'#e6e6e6'})
r=pickle.load(open('lengths_res.pkl','rb')); ns=[256,512,1024,2048]
fig,ax=plt.subplots(1,4,figsize=(7.6,2.6))
for a,H in zip(ax[:3],[0.5,0.8,0.9]):
    for cfg,lab,c,m in [('mirror','mirror','#2a78d6','o'),('interior','interior only','#1baf7a','D'),('periodic','periodic','#eb6834','s')]:
        a.loglog(ns,[r[(n,H,cfg)]['rmse'] for n in ns],m+'-',color=c,lw=1.5,ms=4.5,label=lab)
    y0=r[(256,H,'mirror')]['rmse']; a.loglog(ns,[y0*(n/256)**-0.5 for n in ns],':',color='#555',lw=1,label=r'$n^{-1/2}$')
    a.set_title(f'RMSE, $H={H}$',fontsize=9); a.set_xscale('log',base=2); a.set_xlabel('$n$'); a.set_xticks(ns); a.set_xticklabels(['256','512','1024','2048'],fontsize=7)
    a.yaxis.set_minor_formatter(mt.NullFormatter()); a.set_yticks([0.02,0.05,0.1,0.2]); a.set_yticklabels(['0.02','0.05','0.1','0.2'])
h,l=ax[0].get_legend_handles_labels(); fig.legend(h,l,frameon=False,fontsize=8,ncol=4,loc='upper center')
for H,c in zip([0.5,0.8,0.9],['#2a78d6','#eb6834','#1baf7a']):
    ax[3].loglog(ns,[r[(n,H,'mirror')]['pmin'] for n in ns],'o-',color=c,lw=1.5,ms=4.5,label=f'$H={H}$')
ax[3].set_xscale('log',base=2); ax[3].set_title('smallest share in window',fontsize=9); ax[3].set_xlabel('$n$'); ax[3].set_xticks(ns); ax[3].set_xticklabels(['256','512','1024','2048'],fontsize=7); ax[3].legend(frameon=False,fontsize=7,loc='lower left')
fig.tight_layout(rect=(0,0,1,0.9)); fig.savefig('Figs/fig_lengths.pdf'); fig.savefig('/tmp/fl.png',dpi=100)

import numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from qwt import daubechies, dwt_matrix
from recfloor import fgn
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#888'})
rng=np.random.default_rng(4); n=512; H=0.8; B=np.cumsum(fgn(n,H,rng,1)[0]); h=daubechies(2)
per=np.r_[B,B]; mir=np.r_[B,B[::-1]]
fig,ax=plt.subplots(2,2,figsize=(7.2,4.4))
t=np.arange(2*n)
ax[0,0].plot(t,per,color='#eb6834',lw=1); ax[0,0].axvline(n,color='#999',lw=.8,ls='--'); ax[0,0].set_title('(a) periodic: path followed by itself',loc='left',fontsize=9)
ax[0,1].plot(t,mir,color='#2a78d6',lw=1); ax[0,1].axvline(n,color='#999',lw=.8,ls='--'); ax[0,1].set_title('(b) mirror: path followed by its reversal',loc='left',fontsize=9)
dp=(dwt_matrix(9,6,h)@B)[256:512]**2; dm=(dwt_matrix(10,6,h)@mir)[512:1024]**2
ax[1,0].plot(np.arange(256)*2,dp,color='#eb6834',lw=1); ax[1,0].set_title(f'(c) finest-level energy, periodic: wrap carries {dp.max()/dp.sum():.0%}',loc='left',fontsize=9)
ax[1,1].plot(np.arange(512)*2,dm,color='#2a78d6',lw=1); ax[1,1].set_title(f'(d) finest-level energy, mirror: largest share {dm.max()/dm.sum():.1%}',loc='left',fontsize=9)
for a in ax[1]: a.set_xlabel('sample position'); a.set_ylabel(r'$d_{J-1,k}^2$')
for a in ax[0]: a.set_ylabel('$B_t$')
fig.tight_layout(); fig.savefig('Figs/fig_boundary.pdf'); fig.savefig('/tmp/fb.png',dpi=100)

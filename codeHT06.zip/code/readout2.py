"""HT05 readout experiment: same mirrored db2 nondecimated records (n=512) read three ways at equal
numbers of calls to A or A^dagger: direct readout of the leading qubits, level Hadamard tests, and
maximum-likelihood amplitude estimation (MLAE, no controlled Grover powers). Per-record results saved."""
import numpy as np, pickle
from qwt import daubechies
from hurst import forms, calib, interp, fitH, n, K
from recfloor import fgn
from countfit import make_count_fit
from mlae import mlae
rng = np.random.default_rng(20261117)
levels, Al, tot = forms(daubechies(2), True, True); U, Rc = calib(Al)
cfit = make_count_fit(U, Rc, interp)
def logfit(phat, var):
    if np.any(phat <= 0): return np.nan, np.nan
    return fitH(np.log2(phat), U, Rc, var)
Hs = [0.5, 0.65, 0.8, 0.9]; budgets = [2 ** 17, 2 ** 20, 2 ** 23]; Rn = 300
out = []
for H in Hs:
    B = np.cumsum(fgn(n, H, rng, Rn), axis=1)
    E = np.stack([np.sum((B @ A) * B, 1) for A in Al], 1); nrm = np.sum((B @ tot) * B, 1); P = E / nrm[:, None]
    for r in range(Rn):
        p = P[r]; ex = logfit(p, np.zeros(K))
        for Q in budgets:
            rec = dict(H=H, Q=Q, r=r, exact=ex[0], pmin=p.min())
            Cd = rng.multinomial(Q, np.r_[p, 1 - p.sum()])[:K].astype(float); Md = np.full(K, float(Q))
            ph = Cd / Md; rec["dir_log"] = logfit(ph, (1 - ph) / (Md * np.maximum(ph, 1e-300)))
            rec["dir_cnt"] = cfit(Cd, Md); rec["dir_zero"] = int((Cd == 0).sum())
            Mh = Q // K; Ch = rng.binomial(Mh, p).astype(float); Mv = np.full(K, float(Mh))
            ph = Ch / Mv; rec["had_log"] = logfit(ph, (1 - ph) / (Mv * np.maximum(ph, 1e-300)))
            rec["had_cnt"] = cfit(Ch, Mv); rec["had_zero"] = int((Ch == 0).sum())
            res = [mlae(pj, Q // K, rng) for pj in p]; pa = np.array([x[0] for x in res]); va = np.array([x[1] for x in res])
            rec["ae_log"] = logfit(pa, va); rec["ae_zero"] = int((pa == 0).sum()); rec["ae_calls"] = sum(x[2] for x in res)
            out.append(rec)
        if r % 50 == 0: print(H, r, flush=True)
    pickle.dump(out, open("readout2_res.pkl", "wb"))
print("done")

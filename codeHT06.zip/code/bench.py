"""CNOT counts and CNOT-depth estimates under stated decompositions (no transpiler available).
Model: c-controlled X/Z (c>=3) = 2c-3 Toffolis with c-2 clean ancillas, Toffoli = 6 CNOT; c=2: 6; c=1: 1.
c-controlled single-qubit U: c=1: 2 CNOT; c>=2: AND into ancilla (2x MCX_c) + 2.
c-controlled swap = 2 CNOT + MCX_{c+1}. Open controls cost no CNOTs.
Depth: ASAP schedule of gates, each occupying its qubits for its CNOT count."""
import numpy as np
from qwt import daubechies, qwt_ops, mirror_ops, shift_ops, level_reflection, threshold_reflection
def mcx(c): return 0 if c == 0 else 1 if c == 1 else 6 if c == 2 else 6 * (2 * c - 3)
def cost(op):
    k = op[0]; ctrls = op[-1]; c = len(ctrls)
    if k in ("x", "z"): return mcx(c)
    if k in ("u", "p"): return 0 if c == 0 else 2 if c == 1 else 2 * mcx(c) + 2
    if k == "swap": return 3 if c == 0 else 2 + mcx(c + 1)
def stats(ops):
    tot = 0; avail = {}
    for op in ops:
        cst = cost(op); tot += cst
        qs = [op[1]] + ([op[2]] if op[0] == "swap" else []) + [q for q, _ in op[-1]]
        t0 = max([avail.get(q, 0) for q in qs]); 
        for q in qs: avail[q] = t0 + cst
    return tot, max(avail.values()) if avail else 0
J, L = 10, 6; data = list(range(J)); anc = J
rows = []
rows.append(("mirror", *stats(mirror_ops(data[:-1], J - 1))))
for p in [1, 2, 4]:
    rows.append((f"lattice QWT db{p}", *stats(qwt_ops(data, L, daubechies(p)))))
rows.append(("shift register (L=6)", *stats(shift_ops(data, list(range(J + 1, J + 1 + L))))))
for j in [J - 1, J - 3, J - 6]:
    rows.append((f"controlled reflection, level {j}", *stats(level_reflection(anc, data, j))))
rows.append(("controlled threshold reflection, c=6", *stats(threshold_reflection(anc, data, 6))))
S0 = [("z", 0, [(q, 0) for q in range(1, J)])]
rows.append(("zero reflection S_0 (data)", *stats(S0)))
for r in rows: print(f"{r[0]:40s} CNOT {r[1]:6d}  depth {r[2]:6d}")
# HT05 additions: zero reflection on all preparation registers, Grover iterate (nondecimated db2)
S0nd = [("z", 0, [(q, 0) for q in list(range(1, J)) + list(range(J + 1, J + 1 + L))])]
mir = stats(mirror_ops(data[:-1], J - 1))[0]; sh = stats(shift_ops(data, list(range(J + 1, J + 1 + L))))[0]
qw2 = stats(qwt_ops(data, L, daubechies(2)))[0]; s0 = stats(S0nd)[0]
print("S0 on 16 qubits", s0, "| A without A_B (mirror+shift+db2):", mir + sh + qw2,
      "| Grover iterate without A_B:", 2 * (mir + sh + qw2) + s0, "+ R_j (1..54)")

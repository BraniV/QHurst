import pickle, numpy as np
rs = pickle.load(open("readout3_res.pkl", "rb")); rng = np.random.default_rng(1)
def get(H, Q):
    return [r for r in rs if r["H"] == H and r["Q"] == Q]
def logstats(R, key, H):
    e = np.array([r[key][0] for r in R]); se = np.array([r[key][1] for r in R]); ok = ~np.isnan(e)
    return dict(est=e, ok=ok, rmse=np.sqrt(np.mean((e[ok] - H) ** 2)), bias=np.mean(e[ok] - H), fail=1 - ok.mean(),
                cover=np.mean(np.abs(e[ok] - H) <= 1.96 * se[ok]))
def cntstats(R, key, H, zkey):
    e = np.array([r[key][0] for r in R]); lo = np.array([r[key][1] for r in R]); hi = np.array([r[key][2] for r in R])
    st = np.array([r[key][3] for r in R]); ok = st == "ok"; sp = np.array([r[zkey] > 0 for r in R])
    cov = (lo <= H) & (H <= hi)
    return dict(est=e, ok=ok, rmse=np.sqrt(np.mean((e[ok] - H) ** 2)), bias=np.mean(e[ok] - H), allzero=1 - ok.mean(),
                cover=np.mean(cov[ok]), wide=np.mean((hi - lo)[ok] > 0.4) if ok.any() else np.nan,
                sparse=np.mean(sp), cover_sparse=np.mean(cov[ok & sp]) if (ok & sp).sum() >= 20 else np.nan, nsparse=int((ok & sp).sum()))
def ratio(a, b, H, B=2000):
    m = a["ok"] & b["ok"]; ea = a["est"][m] - H; eb = b["est"][m] - H; n = m.sum()
    r0 = np.sqrt(np.mean(ea ** 2) / np.mean(eb ** 2)); bs = []
    for _ in range(B):
        i = rng.integers(0, n, n); bs.append(np.sqrt(np.mean(ea[i] ** 2) / np.mean(eb[i] ** 2)))
    return r0, np.std(bs)
out = {}
for H in [0.5, 0.65, 0.8, 0.9]:
    for Q in [2 ** 17, 2 ** 20, 2 ** 23]:
        R = get(H, Q)
        ex = np.array([r["exact"] for r in R]); exd = dict(est=ex, ok=~np.isnan(ex)); exr = np.sqrt(np.mean((ex - H) ** 2))
        d = dict(exact=exr, dir_log=logstats(R, "dir_log", H), had_log=logstats(R, "had_log", H), ae=logstats(R, "ae_log", H),
                 dir_cnt=cntstats(R, "dir_cnt2", H, "dir_zero"), had_cnt=cntstats(R, "had_cnt2", H, "had_zero"))
        d["r_ae_dir"] = ratio(d["ae"], d["dir_cnt"], H); d["r_dir_had"] = ratio(d["dir_cnt"], d["had_cnt"], H)
        d["r_ae_exact"] = ratio(d["ae"], exd, H); d["r_dir_exact"] = ratio(d["dir_cnt"], exd, H)
        d["ae_calls"] = np.mean([r["ae_calls"] for r in R]) / Q
        out[(H, Q)] = d
        print(f"H={H} Q=2^{int(np.log2(Q))} exact {exr:.4f} | dir_log {d['dir_log']['rmse']:.4f} f{d['dir_log']['fail']:.3f} c{d['dir_log']['cover']:.2f}"
              f" | dir_cnt {d['dir_cnt']['rmse']:.4f} b{d['dir_cnt']['bias']:+.3f} c{d['dir_cnt']['cover']:.2f} w{d['dir_cnt']['wide']:.3f} az{d['dir_cnt']['allzero']:.3f} sp{d['dir_cnt']['sparse']:.2f} cs{d['dir_cnt']['cover_sparse']:.2f}"
              f" | had_log {d['had_log']['rmse']:.4f} f{d['had_log']['fail']:.3f} b{d['had_log']['bias']:+.3f} | had_cnt {d['had_cnt']['rmse']:.4f} b{d['had_cnt']['bias']:+.3f} c{d['had_cnt']['cover']:.2f} w{d['had_cnt']['wide']:.3f} az{d['had_cnt']['allzero']:.3f} sp{d['had_cnt']['sparse']:.2f} cs{d['had_cnt']['cover_sparse']:.2f}(n{d['had_cnt']['nsparse']})"
              f" | ae {d['ae']['rmse']:.4f} f{d['ae']['fail']:.3f} c{d['ae']['cover']:.2f} b{d['ae']['bias']:+.3f}"
              f" | ae/dir {d['r_ae_dir'][0]:.2f}±{d['r_ae_dir'][1]:.2f} dir/had {d['r_dir_had'][0]:.2f}±{d['r_dir_had'][1]:.2f} ae/ex {d['r_ae_exact'][0]:.2f}±{d['r_ae_exact'][1]:.2f} dir/ex {d['r_dir_exact'][0]:.2f}±{d['r_dir_exact'][1]:.2f}", flush=True)
pickle.dump(out, open("readout3_summary.pkl", "wb"))

import pickle, numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt, matplotlib.ticker as mt
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#888','axes.grid':True,'grid.color':'#e6e6e6'})
S=pickle.load(open('readout3_summary.pkl','rb')); Qs=[2**17,2**20,2**23]
fig,ax=plt.subplots(1,4,figsize=(7.4,2.7),sharey=True)
for a,H in zip(ax,[0.5,0.65,0.8,0.9]):
    for k,lab,c,m in [('dir_cnt','direct readout','#2a78d6','o'),('had_cnt','level tests','#eb6834','s'),('ae','MLAE','#1baf7a','D')]:
        a.plot(np.log2(Qs),[S[(H,Q)][k]['rmse'] for Q in Qs],m+'-',color=c,lw=1.5,ms=4.5,label=lab)
    a.axhline(S[(H,Qs[0])]['exact'],color='#555',ls='--',lw=1,label='exact shares')
    a.set_title(f'$H={H}$',fontsize=9); a.set_xticks([17,20,23]); a.set_xlabel(r'$\log_2$ queries')
ax[0].set_ylabel(r'RMSE of $\widehat H$'); ax[0].set_yscale('log'); ax[0].set_yticks([0.03,0.05,0.1]); ax[0].set_yticklabels(['0.03','0.05','0.10']); ax[0].yaxis.set_minor_formatter(mt.NullFormatter())
h,l=ax[0].get_legend_handles_labels(); fig.legend(h,l,frameon=False,fontsize=8,ncol=4,loc='upper center')
fig.tight_layout(rect=(0,0,1,0.9)); fig.savefig('Figs/fig_readout.pdf'); fig.savefig('/tmp/fr2.png',dpi=100)

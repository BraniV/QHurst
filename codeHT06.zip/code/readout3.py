"""Regenerates exactly the records and counts of readout2.py (same seed, same random-number stream),
stores the counts, and refits the count fit with the exact-intercept multinomial-lognormal likelihood."""
import numpy as np, pickle
from qwt import daubechies
from hurst import forms, calib, interp, n, K
from recfloor import fgn
from mlae import mlae
from countfit2 import make_fit
rng = np.random.default_rng(20261117)
levels, Al, tot = forms(daubechies(2), True, True); U, Rc = calib(Al)
fit = make_fit(U, Rc, interp, K)
old = pickle.load(open("readout2_res.pkl", "rb")); idx = {(r["H"], r["Q"], r["r"]): r for r in old}
Hs = [0.5, 0.65, 0.8, 0.9]; budgets = [2 ** 17, 2 ** 20, 2 ** 23]; Rn = 300; out = []; mism = 0
for H in Hs:
    B = np.cumsum(fgn(n, H, rng, Rn), axis=1)
    E = np.stack([np.sum((B @ A) * B, 1) for A in Al], 1); nrm = np.sum((B @ tot) * B, 1); P = E / nrm[:, None]
    for r in range(Rn):
        p = P[r]
        for Q in budgets:
            o = idx[(H, Q, r)]; rec = dict(o)
            Cd = rng.multinomial(Q, np.r_[p, 1 - p.sum()])[:K].astype(float); Md = np.full(K, float(Q))
            Mh = Q // K; Ch = rng.binomial(Mh, p).astype(float); Mv = np.full(K, float(Mh))
            res = [mlae(pj, Q // K, rng) for pj in p]
            if int((Cd == 0).sum()) != o["dir_zero"] or int((Ch == 0).sum()) != o["had_zero"] or sum(x[2] for x in res) != o["ae_calls"]: mism += 1
            rec["Cd"] = Cd; rec["Ch"] = Ch; rec["p"] = p
            rec["dir_cnt2"] = fit(Cd, Md); rec["had_cnt2"] = fit(Ch, Mv)
            out.append(rec)
    print(H, "mismatches so far", mism, flush=True)
    pickle.dump(out, open("readout3_res.pkl", "wb"))
print("done; stream mismatches:", mism)

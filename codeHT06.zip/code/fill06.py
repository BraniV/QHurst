import pickle, numpy as np
S = pickle.load(open("readout3_summary.pkl", "rb"))
Qs = [2**17, 2**20, 2**23]; Hs = [0.5, 0.65, 0.8, 0.9]; ql = {2**17: "$2^{17}$", 2**20: "$2^{20}$", 2**23: "$2^{23}$"}
def pc(x):
    if x == 0: return "0"
    return f"{100*x:.0f}\\%" if x >= 0.01 else f"{100*x:.1f}\\%"
rows = []
for H in Hs:
    for i, Q in enumerate(Qs):
        d = S[(H, Q)]
        w = lambda k: f"{d[k]['rmse']:.4f}" + (f" [{pc(d[k]['wide'])}]" if d[k]['wide'] > 0 else "")
        ae = f"{d['ae']['rmse']:.4f}" + (f" ({pc(d['ae']['fail'])})" if d['ae']['fail'] > 0 else "")
        rows.append(f"{('$'+str(H)+'$') if i==0 else ''} & {ql[Q]} & {d['exact']:.4f} & {w('dir_cnt')} & {w('had_cnt')} & {ae} & "
                    f"{d['r_ae_exact'][0]:.2f} ({d['r_ae_exact'][1]:.2f}) & {d['r_ae_dir'][0]:.2f} ({d['r_ae_dir'][1]:.2f})\\\\")
    if H != 0.9: rows.append("\\addlinespace")
tab4 = r"""\begin{tabular}{ll c cc c cc}
\toprule
&& exact & direct & level & & \multicolumn{2}{c}{RMSE ratio (SE)}\\
\cmidrule(lr){7-8}
$H$ & queries & shares & readout & tests & MLAE & MLAE/exact & MLAE/direct\\
\midrule
""" + "\n".join(rows) + "\n\\bottomrule\n\\end{tabular}"
rows = []
for H, Q in [(0.65, 2**17), (0.8, 2**17), (0.8, 2**20), (0.9, 2**17), (0.9, 2**20), (0.9, 2**23)]:
    d = S[(H, Q)]; cells = []
    for k in ["dir", "had"]:
        lg = d[k + "_log"]; ct = d[k + "_cnt"]
        cs = f"{ct['cover_sparse']:.2f}" if not np.isnan(ct['cover_sparse']) else "--"
        cells += [pc(lg['fail']), f"${lg['bias']:+.3f}$", f"${ct['bias']:+.3f}$", f"{ct['cover']:.2f} / {cs}", pc(ct['wide']) if ct['wide']>0 else "0"]
    rows.append(f"${H}$ & {ql[Q]} & " + " & ".join(cells) + "\\\\")
tab5 = r"""\begin{tabular}{ll ccccc ccccc}
\toprule
&& \multicolumn{5}{c}{direct readout} & \multicolumn{5}{c}{level tests}\\
\cmidrule(lr){3-7}\cmidrule(lr){8-12}
&& \multicolumn{2}{c}{log fit} & \multicolumn{3}{c}{count fit} & \multicolumn{2}{c}{log fit} & \multicolumn{3}{c}{count fit}\\
\cmidrule(lr){3-4}\cmidrule(lr){5-7}\cmidrule(lr){8-9}\cmidrule(lr){10-12}
$H$ & queries & fail & bias & bias & cover & wide & fail & bias & bias & cover & wide\\
\midrule
""" + "\n".join(rows) + "\n\\bottomrule\n\\end{tabular}"
open("tab4_v6.tex", "w").write(tab4); open("tab5_v6.tex", "w").write(tab5)
for k in [(0.9,2**20),(0.8,2**20),(0.9,2**17)]:
    d=S[k]; print(k, d['exact'], d['dir_cnt']['rmse'], d['had_cnt']['rmse'], d['ae']['rmse'], d['r_ae_exact'], d['r_ae_dir'], d['r_dir_had'], d['r_dir_exact'])

import numpy as np
from qwt import daubechies, dwt_matrix, qwt_ops
from recfloor import fgn
n = 512; K = 6; rng = np.random.default_rng(9)
for p in [2, 4]:
    h = daubechies(p)
    for mir in [False, True]:
        J = 10 if mir else 9; N = 2 ** J; Wm = dwt_matrix(J, K, h)
        M = np.vstack([np.eye(n), np.eye(n)[::-1]]) if mir else np.eye(n)
        cuts = [(n - 1, n), (N - 1, 0)] if mir else [(n - 1, 0)]
        row = []
        for H in [0.3, 0.5, 0.8]:
            B = np.cumsum(fgn(n, H, rng, 300), 1); C = (Wm @ M @ B.T) ** 2
            sh = []
            for j in [J - 1, J - 3, J - K]:
                rows = Wm[2 ** j:2 ** (j + 1)]; nz = np.abs(rows) > 1e-12
                bd = np.array([any(r[a] and r[b] for a, b in cuts) for r in nz])
                sh.append(C[2 ** j:2 ** (j + 1)][bd].sum() / C[2 ** j:2 ** (j + 1)].sum())
            row.append(sh)
        print(f"db{p} {'mirror  ' if mir else 'periodic'} boundary share at depth 0,2,5:", "  ".join(f"H={H}: " + "/".join(f"{v:.3f}" for v in s) for H, s in zip([0.3, 0.5, 0.8], row)), " (#bd coefs per level:", [int(sum(any(r[a] and r[b] for a,b in cuts) for r in (np.abs(Wm[2**j:2**(j+1)])>1e-12))) for j in [J-1,J-3,J-K]], ")")
# gate counts of the lattice QWT
for p in [1, 2, 4]:
    for J, L in [(10, 6), (20, 6)]:
        ops = qwt_ops(list(range(J)), L, daubechies(p))
        mcx = sum(1 for o in ops if o[0] == "x"); u = sum(1 for o in ops if o[0] == "u"); sw = sum(1 for o in ops if o[0] == "swap")
        maxc = max(len(o[-1]) for o in ops)
        print(f"db{p} J={J} L={L}: rotations {u}, multi-controlled X {mcx}, controlled swaps {sw}, max controls {maxc}")

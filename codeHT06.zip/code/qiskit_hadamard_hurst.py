"""Aer run of the level tests (Hadamard tests of level reflections) for a mirrored fBm path.
Requires qiskit>=2.0, qiskit-aer, numpy; imports gate lists from qwt.py.
Usage: python3 qiskit_hadamard_hurst.py  [n=64, db2, L=3, shots per level=20000]"""
import numpy as np
from qwt import daubechies, qwt_ops, mirror_ops, hadamard_test, level_reflection, to_qiskit, dwt_matrix
from qiskit import QuantumCircuit, transpile
from qiskit.circuit.library import StatePreparation
from qiskit_aer import AerSimulator

def fbm_path(n, H, rng):
    k = np.arange(n); g = 0.5 * (np.abs(k + 1) ** (2 * H) + np.abs(k - 1) ** (2 * H) - 2 * k ** (2.0 * H))
    C = np.array([[g[abs(i - j)] for j in range(n)] for i in range(n)])
    return np.cumsum(np.linalg.cholesky(C + 1e-12 * np.eye(n)) @ rng.standard_normal(n))

def level_test_circuit(B, h, L, j):
    n = len(B); J = int(np.log2(n)) + 1; anc = J; data = list(range(J))
    qc = QuantumCircuit(J + 1, 1)
    qc.append(StatePreparation(B / np.linalg.norm(B)), data[:-1])           # record on qubits 0..J-2
    ops = mirror_ops(data[:-1], J - 1) + qwt_ops(data, L, h) + hadamard_test(anc, level_reflection(anc, data, j))
    qc.compose(to_qiskit(ops, J + 1), inplace=True)
    qc.measure(anc, 0); return qc

if __name__ == "__main__":
    rng = np.random.default_rng(1); n, H, L, shots = 64, 0.7, 3, 20000
    B = fbm_path(n, H, rng); h = daubechies(2); J = int(np.log2(n)) + 1
    Bt = np.r_[B, B[::-1]]; w = dwt_matrix(J, L, h) @ Bt / np.linalg.norm(Bt)
    sim = AerSimulator()
    for j in range(J - L, J):
        qc = transpile(level_test_circuit(B, h, L, j), sim)
        c = sim.run(qc, shots=shots).result().get_counts()
        print(f"level {j}: Hadamard estimate {c.get('1', 0) / shots:.5f}   exact {np.sum(w[2**j:2**(j+1)]**2):.5f}")

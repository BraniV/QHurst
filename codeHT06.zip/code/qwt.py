"""Quantum wavelet transform for any orthonormal Daubechies filter via the paraunitary lattice,
mirror extension, shift register, and Hadamard tests of level reflections.
Gate lists are verified with a NumPy state-vector simulator; to_qiskit() emits Qiskit 2.x circuits.
Indexing: N = 2^J, V_J = V_{J-L} + W_{J-L} + ... + W_{J-1}; W_j occupies indices [2^j, 2^{j+1});
qubit q carries index bit b_q (little endian)."""
import numpy as np

# ---------------------------------------------------------------- Daubechies filters
def daubechies(p):
    """Orthonormal Daubechies lowpass filter with p vanishing moments (length 2p), minimum phase."""
    from math import comb
    yr = np.roots([comb(p - 1 + k, k) for k in range(p)][::-1]) if p > 1 else np.array([])
    zr = []
    for y in yr:
        r = np.roots([1, -(2 - 4 * y), 1]); zr.append(r[np.argmin(np.abs(r))])
    h = np.real(np.poly(zr)) if zr else np.array([1.0])
    for _ in range(p): h = np.convolve(h, [1, 1])
    return h / h.sum() * np.sqrt(2)

def highpass(h):
    n = len(h); return np.array([(-1) ** k * h[n - 1 - k] for k in range(n)])

# ---------------------------------------------------------------- lattice factorization
def lattice(h):
    """Return [R_0, R_1, ..., R_{K-1}] (2x2 orthogonal) with E(z) = R_{K-1} Lam R_{K-2} ... Lam R_0,
    E(z) = sum_m E_m z^m, E_m = [[h_2m, h_2m+1],[g_2m, g_2m+1]], Lam = diag(1, z) (advance odd channel)."""
    g = highpass(h); K = len(h) // 2
    E = [np.array([[h[2 * m], h[2 * m + 1]], [g[2 * m], g[2 * m + 1]]]) for m in range(K)]
    Rs = []
    while len(E) > 1:
        top = E[-1]; u, s, vt = np.linalg.svd(top); r1 = u[:, 1]          # r1 orthogonal to col(E_top)
        r2 = np.array([-r1[1], r1[0]])
        if np.linalg.norm(r2 @ E[0]) > 1e-9: r2 = -r2
        R = np.column_stack([r1, r2])
        F = [R.T @ Em for Em in E]
        assert np.allclose(F[-1][0], 0, atol=1e-9) and np.allclose(F[0][1], 0, atol=1e-9)
        # E' = Lam^{-1} R^T E : row 1 shifts down one power
        newE = []
        for m in range(len(E) - 1):
            newE.append(np.vstack([F[m][0], F[m + 1][1]]))
        Rs.append(R); E = newE
    Rs.append(E[0]); return Rs[::-1]          # R_0 first

# ---------------------------------------------------------------- gate lists
def dec_ops(reg, ctrls):           # |v> -> |v-1 mod 2^len(reg)>, reg LSB first
    return [("x", reg[q], ctrls + [(reg[p], 0) for p in range(q)]) for q in range(len(reg) - 1, -1, -1)]
def inc_ops(reg, ctrls):
    return [("x", reg[q], ctrls + [(reg[p], 1) for p in range(q)]) for q in range(len(reg) - 1, -1, -1)]

def qwt_ops(data, L, h):
    """Orthonormal periodic DWT with L levels in Mallat order, any filter h (via lattice)."""
    J = len(data); Rs = lattice(h); ops = []
    for j in range(J - 1, J - L - 1, -1):                 # produce W_j, finest J-1 first
        ctrls = [(data[q], 0) for q in range(j + 1, J)]  # act on approximation block of V_{j+1}
        kreg = [data[q] for q in range(1, j + 1)]        # position register of the pair index
        for m, R in enumerate(Rs):
            if m > 0: ops += dec_ops(kreg, ctrls + [(data[0], 1)])   # advance odd channel
            ops.append(("u", data[0], R, ctrls))
        for q in range(j): ops.append(("swap", data[q], data[q + 1], ctrls))   # flag -> qubit j
    return ops

def mirror_ops(data, e):           # even extension: |0>|x> + |1>|reverse x>, e = new top qubit
    return [("u", e, np.array([[1, 1], [1, -1]]) / np.sqrt(2), [])] + [("x", q, [(e, 1)]) for q in data]

def shift_ops(data, sreg):         # |s>|k> -> |s>|k+s mod N>, sreg LSB first, coherent adder
    ops = []
    for b, sq in enumerate(sreg): ops += inc_ops(data[b:], [(sq, 1)])
    return ops

def level_reflection(anc, data, j):      # controlled (I - 2 P_j): Z on qubit j, open controls above
    J = len(data); return [("z", data[j], [(anc, 1)] + [(data[q], 0) for q in range(j + 1, J)])]
def threshold_reflection(anc, data, c):  # controlled (I - 2 Pi_c), Pi_c = top c qubits |0>
    J = len(data); return [("z", anc, [(data[J - i], 0) for i in range(1, c + 1)])]
def phase_ops(anc, data, levels, omega): # controlled D_f, f(j) = exp(i omega j) on W_j
    J = len(data); return [("p", data[j], omega * j, [(anc, 1)] + [(data[q], 0) for q in range(j + 1, J)]) for j in levels]
def hadamard_test(anc, cU, quad="re"):
    Hm = np.array([[1, 1], [1, -1]]) / np.sqrt(2)
    ops = [("u", anc, Hm, [])] + cU
    if quad == "im": ops.append(("u", anc, np.diag([1, -1j]), []))
    return ops + [("u", anc, Hm, [])]

# ---------------------------------------------------------------- simulator
def apply(ops, psi, nq):
    psi = psi.reshape([2] * nq).astype(complex); ax = lambda q: nq - 1 - q
    for op in ops:
        kind = op[0]
        if kind == "swap": _, a, b, ctrls = op; tg = [a, b]
        elif kind in ("u", "p"): _, a, M, ctrls = op; tg = [a]
        else: _, a, ctrls = op; tg = [a]
        sl = [slice(None)] * nq
        for q, v in ctrls: sl[ax(q)] = v
        sub = psi[tuple(sl)]
        rem = [q for q in range(nq - 1, -1, -1) if q not in [c for c, _ in ctrls]]; pos = {q: i for i, q in enumerate(rem)}
        if kind == "swap": sub = np.swapaxes(sub, pos[a], pos[b])
        else:
            i = pos[a]; s0 = np.take(sub, 0, i); s1 = np.take(sub, 1, i)
            if kind == "x": n0, n1 = s1, s0
            elif kind == "z": n0, n1 = s0, -s1
            elif kind == "p": n0, n1 = s0, np.exp(1j * M) * s1
            else: n0, n1 = M[0, 0] * s0 + M[0, 1] * s1, M[1, 0] * s0 + M[1, 1] * s1
            sub = np.stack([n0, n1], i)
        psi[tuple(sl)] = sub
    return psi.reshape(-1)

def unitary(ops, nq):
    return np.column_stack([apply(ops, np.eye(2 ** nq)[:, k], nq) for k in range(2 ** nq)])

# ---------------------------------------------------------------- classical reference
def dwt_matrix(J, L, h):
    """Periodic orthonormal DWT, Mallat order: a_k = sum h_n x_{2k+n}, d_k = sum g_n x_{2k+n}."""
    g = highpass(h); N = 2 ** J; out = np.zeros((N, N)); A = np.eye(N)
    for j in range(J - 1, J - L - 1, -1):
        n = A.shape[0]; Hm = np.zeros((n // 2, n)); Gm = np.zeros((n // 2, n))
        for k in range(n // 2):
            for t in range(len(h)): Hm[k, (2 * k + t) % n] += h[t]; Gm[k, (2 * k + t) % n] += g[t]
        out[2 ** j:2 ** (j + 1)] = Gm @ A; A = Hm @ A
    out[:2 ** (J - L)] = A; return out

# ---------------------------------------------------------------- Qiskit emitter
def to_qiskit(ops, nq):
    from qiskit import QuantumCircuit
    from qiskit.circuit.library import XGate, ZGate, PhaseGate, SwapGate, UnitaryGate
    qc = QuantumCircuit(nq)
    for op in ops:
        kind = op[0]
        if kind == "swap": _, a, b, ctrls = op; g, tg = SwapGate(), [a, b]
        elif kind == "u": _, a, M, ctrls = op; g, tg = UnitaryGate(np.asarray(M, complex)), [a]
        elif kind == "p": _, a, th, ctrls = op; g, tg = PhaseGate(th), [a]
        else: _, a, ctrls = op; g, tg = {"x": XGate, "z": ZGate}[kind](), [a]
        if ctrls:
            cq = [q for q, _ in ctrls]; st = sum(v << i for i, (_, v) in enumerate(ctrls))
            qc.append(g.control(len(cq), ctrl_state=st), cq + tg)
        else: qc.append(g, tg)
    return qc

# ---------------------------------------------------------------- verification
if __name__ == "__main__":
    rng = np.random.default_rng(0)
    for p in [1, 2, 3, 4]:
        h = daubechies(p); g = highpass(h)
        mom = [abs(sum(g * np.arange(len(g)) ** r)) for r in range(p)]
        J, L = 7, 3
        U = unitary(qwt_ops(list(range(J)), L, h), J)
        D = dwt_matrix(J, L, h)
        print(f"db{p}: len {len(h)}, |sum h - sqrt2| {abs(h.sum()-np.sqrt(2)):.1e}, max moment {max(mom):.1e}, "
              f"lattice stages {len(lattice(h))}, ||U - DWT|| {np.abs(U - D).max():.1e}, ||U^T U - I|| {np.abs(U.conj().T@U-np.eye(2**J)).max():.1e}")
    # mirror
    J = 6; x = rng.standard_normal(2 ** (J - 1)); xs = np.r_[x, x[::-1]] / np.linalg.norm(np.r_[x, x[::-1]])
    psi0 = np.zeros(2 ** J, complex); psi0[:2 ** (J - 1)] = x / np.linalg.norm(x)
    out = apply(mirror_ops(list(range(J - 1)), J - 1), psi0, J)
    print("mirror err", np.abs(out - xs).max())
    # Hadamard tests of level reflections after mirror + db2, decimated
    h = daubechies(2); L = 3; nq = J + 1; anc = J
    state = np.zeros(2 ** nq, complex); state[:2 ** J] = xs
    w = dwt_matrix(J, L, h) @ xs; err = 0
    for j in range(J - L, J):
        ops = qwt_ops(list(range(J)), L, h) + hadamard_test(anc, level_reflection(anc, list(range(J)), j))
        st = apply(ops, state, nq); p1 = np.sum(np.abs(st[2 ** J:]) ** 2)
        err = max(err, abs(p1 - np.sum(w[2 ** j:2 ** (j + 1)] ** 2)))
    print("Hadamard level tests: max |P(anc=1) - E_j/||x||^2|", err)
    # characteristic function test
    om = 0.7; levels = list(range(J - L, J))
    E = {j: np.sum(w[2 ** j:2 ** (j + 1)] ** 2) for j in levels}; target = sum(E.values()) - sum(E.values()) + sum(np.exp(1j*om*j)*E[j] for j in levels) + (1 - sum(E.values()))
    vals = []
    for quad in ["re", "im"]:
        st = apply(qwt_ops(list(range(J)), L, h) + hadamard_test(anc, phase_ops(anc, list(range(J)), levels, om), quad), state, nq)
        vals.append(np.sum(np.abs(st[:2 ** J]) ** 2) - np.sum(np.abs(st[2 ** J:]) ** 2))
    print("char-function test err", abs(vals[0] - target.real), abs(vals[1] - target.imag))
    # coherent shift register (NDWT): reduced level masses = average over shifts
    Ls = 2; nq2 = J + Ls; sreg = [J, J + 1]
    st = np.zeros(2 ** nq2, complex); st[:2 ** J] = xs
    Hm = np.array([[1, 1], [1, -1]]) / np.sqrt(2)
    ops = [("u", q, Hm, []) for q in sreg] + shift_ops(list(range(J)), sreg) + qwt_ops(list(range(J)), L, h)
    st = apply(ops, st, nq2); probs = (np.abs(st) ** 2).reshape(2 ** Ls, 2 ** J).sum(0)
    avg = np.mean([(dwt_matrix(J, L, h) @ np.roll(xs, s)) ** 2 for s in range(2 ** Ls)], 0)
    print("shift-register masses err", np.abs(probs - avg).max())

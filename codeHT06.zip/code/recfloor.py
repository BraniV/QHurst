"""Record-noise scaling of wavelet log-energy slopes for fBm paths: Haar (1 vanishing moment) vs D4 (2)."""
import numpy as np, sys
def fgn(N, H, rng, R):
    k = np.arange(N + 1); g = 0.5 * ((k + 1.) ** (2 * H) + np.abs(k - 1.) ** (2 * H) - 2 * k ** (2. * H))
    c = np.r_[g, g[-2:0:-1]]; lam = np.fft.fft(c).real; lam[lam < 0] = 0
    M = len(c); Z = rng.standard_normal((R, M)) + 1j * rng.standard_normal((R, M))
    X = np.fft.fft(np.sqrt(lam / M)[None] * Z, axis=1)
    return X.real[:, :N]
h_haar = np.array([1, 1]) / np.sqrt(2)
s3 = np.sqrt(3); h_d4 = np.array([1 + s3, 3 + s3, 3 - s3, 1 - s3]) / (4 * np.sqrt(2))
def qmf(h): return np.array([(-1) ** k * h[len(h) - 1 - k] for k in range(len(h))])
def level_energies(B, h, L):
    """Decimated DWT with 'valid' (non-wrapping) filtering; returns mean squared detail per level, finest first."""
    g = qmf(h); a = B; out = []
    for r in range(L):
        ca = np.stack([np.convolve(x, h[::-1], 'valid')[::2] for x in a]); cd = np.stack([np.convolve(x, g[::-1], 'valid')[::2] for x in a])
        out.append((cd ** 2).mean(1)); a = ca
    return np.array(out)        # out[r] = level J-1-r
def run(H, N, R, rng, K=6):
    B = np.cumsum(fgn(N, H, rng, R), axis=1)
    res = {}
    for name, h in [('Haar', h_haar), ('D4', h_d4)]:
        E = level_energies(B, h, K); y = np.log2(E)               # (K, R)
        r = np.arange(K); X = r - r.mean()
        slope = (X[:, None] * (y - y.mean(0))).sum(0) / (X ** 2).sum()   # slope in depth r: ~ 2H+1 per level
        res[name] = slope.std() / 2                                 # on the H scale
    return res
if __name__ == '__main__':
    rng = np.random.default_rng(1); Ns = [2 ** k for k in range(9, 16)]
    print('H N sdHaar sdD4')
    for H in [0.3, 0.5, 0.7, 0.8, 0.9]:
        rows = []
        for N in Ns:
            R = 400 if N <= 2 ** 13 else 200
            r = run(H, N, R, rng); rows.append((N, r['Haar'], r['D4'])); print(H, N, '%.4f %.4f' % (r['Haar'], r['D4']), flush=True)
        rows = np.array(rows); lN = np.log(rows[:, 0])
        bh = np.polyfit(lN[2:], np.log(rows[2:, 1]), 1)[0]; bd = np.polyfit(lN[2:], np.log(rows[2:, 2]), 1)[0]
        print(f'H={H}: exponent Haar {bh:.3f} (theory {max(-0.5, 2*H-2):.2f}), D4 {bd:.3f} (theory -0.50)', flush=True)

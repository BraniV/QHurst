"""Maximum-likelihood amplitude estimation (no phase estimation): Grover powers m = 0,1,2,4,...,
N shots each, uses N * sum(2m+1) calls to A or A^dagger; sequential grid MLE for theta."""
import numpy as np
def schedule(B, nmin=100):
    ms = [0, 1]
    while True:
        nxt = ms + [2 * ms[-1]]
        if B // sum(2 * m + 1 for m in nxt) < nmin: break
        ms = nxt
    Nsh = B // sum(2 * m + 1 for m in ms); return np.array(ms), Nsh
def mlae(p, B, rng):
    ms, Nsh = schedule(B); th = np.arcsin(np.sqrt(p)); k = 2 * ms + 1
    h = rng.binomial(Nsh, np.sin(k * th) ** 2)
    def ll(t, upto):
        s = np.clip(np.sin(np.outer(t, k[:upto])) ** 2, 1e-300, 1 - 1e-16)
        return (h[:upto] * np.log(s) + (Nsh - h[:upto]) * np.log1p(-s)).sum(1)
    if h.sum() == 0: return 0.0, np.inf, int(Nsh * k.sum())
    t = np.linspace(1e-6, np.pi / 2 - 1e-6, 20001); n0 = min(3, len(k)); est = t[np.argmax(ll(t, n0))]
    for j in range(n0, len(k) + 1):
        sd = 1 / (2 * np.sqrt(Nsh * np.sum(k[:j - 1] ** 2))); w = min(6 * sd, np.pi / (4 * k[j - 1]))
        t = np.linspace(max(1e-9, est - w), min(np.pi / 2 - 1e-9, est + w), 801)
        est = t[np.argmax(ll(t, j))]
    step = np.pi / (k[-1] * 40); t = np.arange(max(1e-9, 0.5 * est), min(np.pi / 2, 1.5 * est + 10 * step), step)
    lt = ll(t, len(k)); est = t[np.argmax(lt)]
    t = np.linspace(est - step, est + step, 81); est = t[np.argmax(ll(t, len(k)))]
    a = np.sin(est) ** 2; vth = 1 / (4 * Nsh * np.sum(k ** 2)); vlog = (2 / np.tan(est)) ** 2 * vth
    return a, vlog, int(Nsh * k.sum())
if __name__ == "__main__":
    rng = np.random.default_rng(0)
    for B in [2**17 // 6, 2**20 // 6, 2**23 // 6]:
        ms, N = schedule(B); print(B, ms[-1], N, N * (2 * ms + 1).sum() / B)
        for p in [1e-1, 1e-3, 1e-5, 1e-6]:
            est = np.array([mlae(p, B, rng)[0] for _ in range(300)])
            print("   p %.0e  rel rmse %.3f  zero %.2f  pred sd %.3f" % (p, np.sqrt(np.mean((est / p - 1) ** 2)), np.mean(est == 0), np.sqrt(mlae(p, B, rng)[1])))

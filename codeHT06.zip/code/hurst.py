"""Hurst estimation from Hadamard-test level masses: mirror vs periodic boundary, db2/db4, decimated/nondecimated."""
import numpy as np, sys, pickle
from scipy.linalg import toeplitz
from qwt import daubechies, dwt_matrix
from recfloor import fgn
n = 512; K = 6; Hgrid = np.round(np.arange(0.02, 0.99, 0.04), 2)
def path_cov(n, H):
    t = np.arange(1, n + 1, dtype=float)
    return 0.5 * (t[:, None] ** (2 * H) + t[None] ** (2 * H) - np.abs(t[:, None] - t[None]) ** (2 * H))
def forms(h, mirror, nd):
    """Quadratic-form matrices Abar_j (n x n) for the K finest levels, B -> E_j = B^T Abar_j B."""
    if mirror: J = int(np.log2(n)) + 1; M = np.vstack([np.eye(n), np.eye(n)[::-1]])
    else: J = int(np.log2(n)); M = np.eye(n)
    N = 2 ** J; Wm = dwt_matrix(J, K, h); shifts = range(2 ** K) if nd else [0]
    levels = list(range(J - K, J)); A = {j: np.zeros((n, n)) for j in levels}
    for s in shifts:
        As = Wm @ np.roll(np.eye(N), s, axis=0) @ M          # W S^s M  (S^s: x -> x shifted by s)
        for j in levels:
            R = As[2 ** j:2 ** (j + 1)]; A[j] += R.T @ R / len(shifts)
    tot = M.T @ M                                             # ||x~||^2 = B^T M^T M B
    return levels, [A[j] for j in levels], tot
def calib(Alist):
    out = []
    for H in Hgrid:
        S = path_cov(n, H); C = [A @ S for A in Alist]
        e = np.array([np.trace(c) for c in C])
        G = np.array([[2 * np.sum(ci * cj.T) for cj in C] for ci in C])
        out.append((np.log2(e), G / np.outer(e, e)))
    U = np.array([o[0] for o in out]); R = np.array([o[1] for o in out]); return U, R
def interp(H, U, R):
    H = np.clip(H, Hgrid[0], Hgrid[-1]); i = min(np.searchsorted(Hgrid, H) - 1, len(Hgrid) - 2); i = max(i, 0)
    w = (H - Hgrid[i]) / (Hgrid[i + 1] - Hgrid[i]); return (1 - w) * U[i] + w * U[i + 1], (1 - w) * R[i] + w * R[i + 1]
def fitH(z, U, R, shotvar, H0=None):
    fine = np.linspace(0.0, 1.0, 1001); one = np.ones(len(z))
    def Q(H, Vi):
        u, _ = interp(H, U, R); r = z - u; P = Vi - np.outer(Vi @ one, one @ Vi) / (one @ Vi @ one); return r @ P @ r
    if H0 is None:
        H0 = fine[np.argmin([Q(H, np.eye(len(z))) for H in fine[::10]]) * 10]
    for _ in range(2):
        _, Rr = interp(H0, U, R); V = (Rr + np.diag(shotvar)) / np.log(2) ** 2; Vi = np.linalg.inv(V)
        H0 = fine[np.argmin([Q(H, Vi) for H in fine])]
    u1, _ = interp(min(H0 + 0.01, 0.98), U, R); u0, _ = interp(max(H0 - 0.01, 0.02), U, R)
    d = (u1 - u0) / (min(H0 + 0.01, 0.98) - max(H0 - 0.01, 0.02))
    P = Vi - np.outer(Vi @ one, one @ Vi) / (one @ Vi @ one); se = 1 / np.sqrt(d @ P @ d)
    return H0, se
if __name__ == "__main__":
    cfgs = [("db2", 2, True, False), ("db2", 2, True, True), ("db4", 4, True, True), ("db2", 2, False, False), ("db2", 2, False, True)]
    budgets = [None, 6 * 2 ** 14, 6 * 2 ** 18]
    Hs = [0.2, 0.35, 0.5, 0.65, 0.8, 0.9]; Rn = 500; rng = np.random.default_rng(42)
    res = {}
    setup = {}
    for name, p, mir, nd in cfgs:
        h = daubechies(p); levels, Al, tot = forms(h, mir, nd); U, Rc = calib(Al); setup[(name, mir, nd)] = (levels, Al, tot, U, Rc)
        print("calibrated", name, "mirror" if mir else "periodic", "ND" if nd else "D", flush=True)
    for H in Hs:
        B = np.cumsum(fgn(n, H, rng, Rn), axis=1)
        for key, (levels, Al, tot, U, Rc) in setup.items():
            E = np.stack([np.sum((B @ A) * B, 1) for A in Al], 1); nrm = np.sum((B @ tot) * B, 1); P = E / nrm[:, None]
            for Q in budgets:
                est = []; se = []; fail = 0
                for r in range(Rn):
                    if Q is None: z = np.log2(P[r]); sv = np.zeros(K)
                    else:
                        Mj = Q // K; c = rng.binomial(Mj, P[r])
                        if np.any(c == 0): fail += 1; continue
                        ph = c / Mj; z = np.log2(ph); sv = (1 - ph) / (Mj * ph)
                    a, s = fitH(z, U, Rc, sv); est.append(a); se.append(s)
                est = np.array(est); se = np.array(se)
                res[(key, H, Q)] = dict(rmse=np.sqrt(np.mean((est - H) ** 2)), bias=np.mean(est - H), cover=np.mean(np.abs(est - H) <= 1.96 * se),
                                        fail=fail / Rn, pmin=np.median(P.min(1)), pmax=np.median(P.max(1)))
                d = res[(key, H, Q)]
                print(key, H, Q, " rmse %.4f bias %+.4f cover %.3f fail %.3f  p_min %.2e p_max %.2e" % (d['rmse'], d['bias'], d['cover'], d['fail'], d['pmin'], d['pmax']), flush=True)
            # calibration check
            if Q is None and H in (0.5, 0.8):
                u, _ = interp(H, U, Rc); print("   calib check: mean log2 E vs u:", np.round(np.log2(E.mean(0)) - u, 3), flush=True)
    pickle.dump(res, open("hurst_res.pkl", "wb"))
